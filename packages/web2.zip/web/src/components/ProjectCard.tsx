import { format } from 'date-fns';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { Project } from '../store/projectsStore';

interface Props {
  project: Project;
  onOpen: () => void;
}

export function ProjectCard({ project, onOpen }: Props) {
  const { summary, name, fileName, lastAnalyzed } = project;

  return (
    <Card
      className="flex flex-col"
      style={{ background: '#0f0f1a', border: '1px solid rgba(99,102,241,0.12)' }}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <span className="font-mono text-sm leading-tight text-foreground">{name}</span>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge
              variant="outline"
              className="font-mono text-[10px] h-5 px-1.5"
              style={{ borderColor: 'rgba(99,102,241,0.3)', color: '#6366f1' }}
            >
              .zip
            </Badge>
            <span className="font-mono text-[10px] text-muted-foreground">
              {format(new Date(lastAnalyzed), 'yyyy-MM-dd')}
            </span>
          </div>
        </div>
        <p className="font-mono text-[10px] text-muted-foreground/50 truncate" title={fileName}>
          {fileName}
        </p>
      </CardHeader>

      <div style={{ borderTop: '1px solid rgba(99,102,241,0.08)', marginInline: 24 }} />

      <CardContent className="py-4">
        <div className="grid grid-cols-3 gap-3">
          <StatCell label="FILES"  value={summary.fileCount} />
          <StatCell label="DEPS"   value={summary.edgeCount} />
          <StatCell label="CYCLES" value={summary.cycleCount} error={summary.cycleCount > 0} />
        </div>
      </CardContent>

      <div style={{ borderTop: '1px solid rgba(99,102,241,0.08)', marginInline: 24 }} />

      <CardFooter className="pt-3">
        <Button
          onClick={onOpen}
          variant="outline"
          className="w-full font-mono text-xs tracking-widest h-9"
          style={{
            borderColor: 'rgba(99,102,241,0.25)',
            color: '#6366f1',
            background: 'rgba(99,102,241,0.06)',
          }}
        >
          OPEN_PROJECT
        </Button>
      </CardFooter>
    </Card>
  );
}

function StatCell({ label, value, error }: { label: string; value: number; error?: boolean }) {
  return (
    <div className="text-center">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div
        className="font-mono text-xl leading-tight mt-0.5 tabular-nums"
        style={{ color: error ? '#ef4444' : '#6366f1' }}
      >
        {value.toLocaleString()}
      </div>
    </div>
  );
}
